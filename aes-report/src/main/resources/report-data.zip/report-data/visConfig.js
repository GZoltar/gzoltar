visualizations = [{
    displayName: "Sunburst",
    iconUrl: "",
    obj: Sunburst
}, {
    displayName: "Vertical partition",
    iconUrl: "",
    obj: VerticalPartition
}, {
    displayName: "Configuration",
    obj: ConfigurationView
}
];