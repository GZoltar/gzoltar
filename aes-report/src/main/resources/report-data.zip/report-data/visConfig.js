visualizations = [{
    displayName: "Sunburst",
    iconUrl: "",
    obj: Sunburst
}, {
    displayName: "Vertical partition",
    iconUrl: "",
    obj: VerticalPartition
}, {
    displayName: "Table",
    obj: Table
}, {
    displayName: "Configuration",
    obj: ConfigurationView
}
/*{
    displayName: "New View",
    obj: function(){
        this.render = function(){
            alert('hello world');
        };
    }
}*/

];